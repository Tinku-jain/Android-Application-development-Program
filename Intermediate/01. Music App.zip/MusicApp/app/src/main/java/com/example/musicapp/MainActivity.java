package com.example.musicapp;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button play, pause, stop;
    MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        play = findViewById(R.id.playBtn);
        pause = findViewById(R.id.pauseBtn);
        stop = findViewById(R.id.stopBtn);

        mediaPlayer = MediaPlayer.create(this, R.raw.song);

        play.setOnClickListener(v -> mediaPlayer.start());

        pause.setOnClickListener(v -> mediaPlayer.pause());

        stop.setOnClickListener(v -> {
            mediaPlayer.stop();
            mediaPlayer = MediaPlayer.create(this, R.raw.song);
        });
    }
}
